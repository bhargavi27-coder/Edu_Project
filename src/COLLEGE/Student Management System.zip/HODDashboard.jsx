import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./HODDashboard.css";

const HODDashboard = () => {
  const navigate = useNavigate();

  const [activeMenu, setActiveMenu] = useState("Dashboard");

  const handleMenuClick = (menu) => {
    setActiveMenu(menu);

    // Add your pages here later
    if (menu === "Student Management") {
      navigate("/student-management");
    }

    if (menu === "Faculty Management") {
      navigate("/faculty-management");
    }

    if (menu === "Faculty Registration Approval") {
      navigate("/faculty-registration-approval");
    }

    if (menu === "Attendance Monitoring") {
      navigate("/attendance-monitoring");
    }

    if (menu === "Outpass Approval") {
      navigate("/outpass-approval");
    }

    if (menu === "Complaint Management") {
      navigate("/complaint-management");
    }

    if (menu === "Department Announcements") {
      navigate("/department-announcements");
    }

    if (menu === "Department Reports") {
      navigate("/department-reports");
    }

    if (menu === "HOD Profile") {
      navigate("/hod-profile");
    }
  };

  const handleLogout = () => {
    navigate("/hod");
  };

  return (
    <div className="hod-dashboard">

      {/* ================= SIDEBAR ================= */}
      <aside className="hod-sidebar">

        <div className="hod-logo">
          <div className="hod-logo-icon">E</div>

          <div>
            <h2>EduLentra</h2>
            <span>Smart Campus</span>
          </div>
        </div>

        <div className="hod-role">
          <span className="role-icon">◈</span>
          <div>
            <small>LOGGED IN AS</small>
            <strong>HOD</strong>
          </div>
        </div>

        <nav className="hod-navigation">

          <p className="menu-title">MAIN MENU</p>

          <button
            className={`hod-menu ${
              activeMenu === "Dashboard" ? "active" : ""
            }`}
            onClick={() => setActiveMenu("Dashboard")}
          >
            <span>⌂</span>
            Dashboard
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "Student Management" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("Student Management")}
          >
            <span>♙</span>
            Student Management
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "Faculty Management" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("Faculty Management")}
          >
            <span>♟</span>
            Faculty Management
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "Faculty Registration Approval" ? "active" : ""
            }`}
            onClick={() =>
              handleMenuClick("Faculty Registration Approval")
            }
          >
            <span>✓</span>
            Faculty Approval
            <b className="notification-count">5</b>
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "Attendance Monitoring" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("Attendance Monitoring")}
          >
            <span>▥</span>
            Attendance
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "Outpass Approval" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("Outpass Approval")}
          >
            <span>▣</span>
            Outpass Approval
            <b className="notification-count orange">8</b>
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "Complaint Management" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("Complaint Management")}
          >
            <span>!</span>
            Complaints
          </button>

          <p className="menu-title">DEPARTMENT</p>

          <button
            className={`hod-menu ${
              activeMenu === "Department Announcements" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("Department Announcements")}
          >
            <span>◉</span>
            Announcements
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "Department Reports" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("Department Reports")}
          >
            <span>▤</span>
            Department Reports
          </button>

          <button
            className={`hod-menu ${
              activeMenu === "HOD Profile" ? "active" : ""
            }`}
            onClick={() => handleMenuClick("HOD Profile")}
          >
            <span>●</span>
            HOD Profile
          </button>

        </nav>

        <div className="sidebar-bottom">

          <button className="settings-button">
            ⚙
            Settings
          </button>

          <button
            className="logout-button"
            onClick={handleLogout}
          >
            ⇥
            Logout
          </button>

        </div>

      </aside>


      {/* ================= MAIN CONTENT ================= */}
      <main className="hod-main">

        {/* TOP HEADER */}
        <header className="hod-header">

          <div>
            <p className="breadcrumb">
              EduLentra / HOD / Dashboard
            </p>

            <h1>Department Dashboard</h1>

            <p className="welcome-text">
              Welcome back, HOD. Here's what's happening in your department.
            </p>
          </div>

          <div className="header-right">

            <button className="header-notification">
              🔔
              <span>3</span>
            </button>

            <div className="hod-user">

              <div className="hod-avatar">
                H
              </div>

              <div>
                <strong>Dr. HOD Name</strong>
                <small>CSE Department</small>
              </div>

              <span className="dropdown-arrow">⌄</span>

            </div>

          </div>

        </header>


        {/* ================= DEPARTMENT INFO ================= */}
        <section className="department-banner">

          <div className="department-icon">
            CSE
          </div>

          <div className="department-info">
            <h2>Computer Science & Engineering</h2>
            <p>
              Department of Computer Science & Engineering
            </p>
          </div>

          <div className="academic-year">
            <span>Academic Year</span>
            <strong>2026 - 2027</strong>
          </div>

        </section>


        {/* ================= STAT CARDS ================= */}
        <section className="hod-stat-grid">

          <div className="hod-stat-card students">

            <div className="stat-icon">
              ♙
            </div>

            <div className="stat-content">
              <span>Total Students</span>
              <h2>684</h2>
              <p>
                <b>+12</b> this semester
              </p>
            </div>

          </div>


          <div className="hod-stat-card faculty">

            <div className="stat-icon">
              ♟
            </div>

            <div className="stat-content">
              <span>Total Faculty</span>
              <h2>42</h2>
              <p>
                <b>38</b> active faculty
              </p>
            </div>

          </div>


          <div className="hod-stat-card approval">

            <div className="stat-icon">
              ✓
            </div>

            <div className="stat-content">
              <span>Pending Approvals</span>
              <h2>13</h2>
              <p>
                <b>5</b> faculty registrations
              </p>
            </div>

          </div>


          <div className="hod-stat-card attendance">

            <div className="stat-icon">
              %
            </div>

            <div className="stat-content">
              <span>Average Attendance</span>
              <h2>87.4%</h2>
              <p>
                <b>+2.4%</b> this month
              </p>
            </div>

          </div>

        </section>


        {/* ================= CONTENT GRID ================= */}
        <section className="hod-content-grid">


          {/* ATTENDANCE */}
          <div className="hod-panel attendance-panel">

            <div className="panel-header">

              <div>
                <h2>Attendance Overview</h2>
                <p>Department attendance performance</p>
              </div>

              <button className="view-button">
                View Details →
              </button>

            </div>


            <div className="attendance-chart">

              <div className="chart-y-axis">
                <span>100%</span>
                <span>75%</span>
                <span>50%</span>
                <span>25%</span>
                <span>0%</span>
              </div>

              <div className="bars">

                <div className="bar-item">
                  <div
                    className="bar"
                    style={{ height: "86%" }}
                  >
                    <span>86%</span>
                  </div>
                  <small>III-A</small>
                </div>

                <div className="bar-item">
                  <div
                    className="bar"
                    style={{ height: "91%" }}
                  >
                    <span>91%</span>
                  </div>
                  <small>III-B</small>
                </div>

                <div className="bar-item">
                  <div
                    className="bar"
                    style={{ height: "79%" }}
                  >
                    <span>79%</span>
                  </div>
                  <small>III-C</small>
                </div>

                <div className="bar-item">
                  <div
                    className="bar"
                    style={{ height: "88%" }}
                  >
                    <span>88%</span>
                  </div>
                  <small>II-A</small>
                </div>

                <div className="bar-item">
                  <div
                    className="bar"
                    style={{ height: "94%" }}
                  >
                    <span>94%</span>
                  </div>
                  <small>II-B</small>
                </div>

                <div className="bar-item">
                  <div
                    className="bar"
                    style={{ height: "83%" }}
                  >
                    <span>83%</span>
                  </div>
                  <small>I-A</small>
                </div>

              </div>

            </div>

          </div>


          {/* PENDING ACTIONS */}
          <div className="hod-panel pending-panel">

            <div className="panel-header">

              <div>
                <h2>Pending Actions</h2>
                <p>Requires your attention</p>
              </div>

              <span className="pending-total">
                13
              </span>

            </div>


            <div className="pending-list">

              <div className="pending-item">

                <div className="pending-icon purple">
                  ✓
                </div>

                <div>
                  <strong>Faculty Registration</strong>
                  <span>5 requests waiting</span>
                </div>

                <button
                  onClick={() =>
                    handleMenuClick(
                      "Faculty Registration Approval"
                    )
                  }
                >
                  →
                </button>

              </div>


              <div className="pending-item">

                <div className="pending-icon orange">
                  ▣
                </div>

                <div>
                  <strong>Outpass Requests</strong>
                  <span>8 requests waiting</span>
                </div>

                <button
                  onClick={() =>
                    handleMenuClick("Outpass Approval")
                  }
                >
                  →
                </button>

              </div>


              <div className="pending-item">

                <div className="pending-icon red">
                  !
                </div>

                <div>
                  <strong>Student Complaints</strong>
                  <span>4 unresolved complaints</span>
                </div>

                <button
                  onClick={() =>
                    handleMenuClick("Complaint Management")
                  }
                >
                  →
                </button>

              </div>

            </div>

          </div>

        </section>


        {/* ================= BOTTOM GRID ================= */}
        <section className="hod-bottom-grid">


          {/* RECENT COMPLAINTS */}
          <div className="hod-panel">

            <div className="panel-header">

              <div>
                <h2>Recent Complaints</h2>
                <p>Latest student complaints</p>
              </div>

              <button className="view-button">
                View All →
              </button>

            </div>


            <div className="complaint-list">

              <div className="complaint-row">

                <div className="complaint-avatar">
                  AS
                </div>

                <div className="complaint-info">
                  <strong>Arjun Sharma</strong>
                  <span>Classroom equipment issue</span>
                </div>

                <span className="status pending">
                  Pending
                </span>

              </div>


              <div className="complaint-row">

                <div className="complaint-avatar">
                  PK
                </div>

                <div className="complaint-info">
                  <strong>Priya Kumar</strong>
                  <span>Lab infrastructure</span>
                </div>

                <span className="status progress">
                  In Progress
                </span>

              </div>


              <div className="complaint-row">

                <div className="complaint-avatar">
                  RV
                </div>

                <div className="complaint-info">
                  <strong>Rahul Verma</strong>
                  <span>Timetable issue</span>
                </div>

                <span className="status resolved">
                  Resolved
                </span>

              </div>

            </div>

          </div>


          {/* ANNOUNCEMENTS */}
          <div className="hod-panel">

            <div className="panel-header">

              <div>
                <h2>Department Announcements</h2>
                <p>Latest department updates</p>
              </div>

              <button
                className="add-announcement"
                onClick={() =>
                  handleMenuClick("Department Announcements")
                }
              >
                + New
              </button>

            </div>


            <div className="announcement-list">

              <div className="announcement">

                <div className="announcement-icon">
                  📢
                </div>

                <div>
                  <strong>
                    Internal Assessment Schedule
                  </strong>

                  <span>
                    Posted 2 hours ago
                  </span>
                </div>

              </div>


              <div className="announcement">

                <div className="announcement-icon">
                  📅
                </div>

                <div>
                  <strong>
                    Faculty Meeting - October 5
                  </strong>

                  <span>
                    Posted yesterday
                  </span>
                </div>

              </div>


              <div className="announcement">

                <div className="announcement-icon">
                  🎓
                </div>

                <div>
                  <strong>
                    Placement Training Program
                  </strong>

                  <span>
                    Posted 2 days ago
                  </span>
                </div>

              </div>

            </div>

          </div>

        </section>


        {/* ================= QUICK ACTIONS ================= */}
        <section className="quick-actions-section">

          <h2>Quick Actions</h2>

          <div className="quick-actions">

            <button
              onClick={() =>
                handleMenuClick("Student Management")
              }
            >
              <span>♙</span>
              <div>
                <strong>Manage Students</strong>
                <small>View & manage students</small>
              </div>
            </button>


            <button
              onClick={() =>
                handleMenuClick("Faculty Management")
              }
            >
              <span>♟</span>
              <div>
                <strong>Manage Faculty</strong>
                <small>Faculty information</small>
              </div>
            </button>


            <button
              onClick={() =>
                handleMenuClick("Department Reports")
              }
            >
              <span>▤</span>
              <div>
                <strong>Generate Report</strong>
                <small>Department reports</small>
              </div>
            </button>


            <button
              onClick={() =>
                handleMenuClick("Department Announcements")
              }
            >
              <span>📢</span>
              <div>
                <strong>Announcement</strong>
                <small>Post department update</small>
              </div>
            </button>

          </div>

        </section>

      </main>

    </div>
  );
};

export default HODDashboard;