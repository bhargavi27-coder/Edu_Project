import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Homepage from "./Homepage";
import About from "./About";

import HighlightsPage from "./HighlightsPage";
import GalleryPage from "./GalleryPage";
import GalleryDetailPage from "./GalleryDetailPage";
import ContactPage from "./ContactPage";

import StudentLogin from "./StudentLogin";
import StudentDashboard from "./StudentDashboard";
import StudentSignup from "./StudentSignup";
import Faculty from "./Faculty";
import Admin from "./Admin";
import HOD from "./HOD";

import HODDashboard from "./HODDashboard";
import HODModulePage from "./HODModulePage";


function Mainc() {
  return (
    <Router>
      <Routes>

        {/* ================= MAIN PAGES ================= */}

        <Route path="/" element={<Homepage />} />

        <Route path="/about" element={<About />} />

        <Route
          path="/highlights"
          element={<HighlightsPage />}
        />

        <Route
          path="/gallery"
          element={<GalleryPage />}
        />

        <Route
          path="/gallery/:type"
          element={<GalleryDetailPage />}
        />

        <Route
          path="/contact"
          element={<ContactPage />}
        />


        {/* ================= STUDENT ================= */}

        <Route
          path="/student"
          element={<StudentLogin />}
        />

        <Route
          path="/student-dashboard"
          element={<StudentDashboard />}
        />

        <Route
          path="/student-signup"
          element={<StudentSignup />}
        />


        {/* ================= FACULTY ================= */}

        <Route
          path="/faculty"
          element={<Faculty />}
        />


        {/* ================= ADMIN ================= */}

        <Route
          path="/admin"
          element={<Admin />}
        />


        {/* ================= HOD LOGIN ================= */}

        <Route
          path="/hod"
          element={<HOD />}
        />


        {/* ================= HOD DASHBOARD ================= */}

        <Route
          path="/hod-dashboard"
          element={<HODDashboard />}
        />


        {/* ================= HOD MODULES ================= */}

        <Route
          path="/student-management"
          element={<HODModulePage />}
        />

        <Route
          path="/faculty-management"
          element={<HODModulePage />}
        />

        <Route
          path="/faculty-registration-approval"
          element={<HODModulePage />}
        />

        <Route
          path="/attendance-monitoring"
          element={<HODModulePage />}
        />

        <Route
          path="/outpass-approval"
          element={<HODModulePage />}
        />

        <Route
          path="/complaint-management"
          element={<HODModulePage />}
        />

        <Route
          path="/department-announcements"
          element={<HODModulePage />}
        />

        <Route
          path="/department-reports"
          element={<HODModulePage />}
        />

        <Route
          path="/hod-profile"
          element={<HODModulePage />}
        />

      </Routes>
    </Router>
  );
}

export default Mainc;