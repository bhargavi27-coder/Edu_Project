import React, { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "./HODModulePage.css";

function HODModulePage() {
  const location = useLocation();
  const navigate = useNavigate();

  /* =====================================================
     PAGE INFORMATION
  ===================================================== */

  const pageData = {
    "/student-management": {
      title: "Student Management",
      icon: "👨‍🎓",
      description: "View and manage students in the department.",
    },

    "/faculty-management": {
      title: "Faculty Management",
      icon: "👨‍🏫",
      description: "View and manage department faculty members.",
    },

    "/faculty-registration-approval": {
      title: "Faculty Registration Approval",
      icon: "✅",
      description: "Review and approve faculty registration requests.",
    },

    "/attendance-monitoring": {
      title: "Attendance Monitoring",
      icon: "📊",
      description: "Monitor attendance across all department classes.",
    },

    "/outpass-approval": {
      title: "Outpass Approval",
      icon: "🎫",
      description: "Review and approve student outpass requests.",
    },

    "/complaint-management": {
      title: "Complaint Management",
      icon: "⚠️",
      description: "Review and manage student complaints.",
    },

    "/department-announcements": {
      title: "Department Announcements",
      icon: "📢",
      description: "Create and manage department announcements.",
    },

    "/department-reports": {
      title: "Department Reports",
      icon: "📑",
      description: "View and generate department reports.",
    },

    "/hod-profile": {
      title: "HOD Profile",
      icon: "👤",
      description: "View and manage your HOD profile.",
    },
  };

  const currentPage = pageData[location.pathname];

  /* =====================================================
     STUDENT DATA
  ===================================================== */

  const initialStudents = [
    {
      id: "CSE001",
      name: "Rahul Kumar",
      email: "rahul@example.com",
      year: "III Year",
      section: "A",
      phone: "9876543210",
      attendance: 91,
      status: "Active",
    },
    {
      id: "CSE002",
      name: "Priya Sharma",
      email: "priya@example.com",
      year: "III Year",
      section: "A",
      phone: "9876543211",
      attendance: 87,
      status: "Active",
    },
    {
      id: "CSE003",
      name: "Arjun Reddy",
      email: "arjun@example.com",
      year: "II Year",
      section: "B",
      phone: "9876543212",
      attendance: 76,
      status: "Active",
    },
    {
      id: "CSE004",
      name: "Sneha Rao",
      email: "sneha@example.com",
      year: "IV Year",
      section: "A",
      phone: "9876543213",
      attendance: 94,
      status: "Active",
    },
    {
      id: "CSE005",
      name: "Vikram Singh",
      email: "vikram@example.com",
      year: "I Year",
      section: "C",
      phone: "9876543214",
      attendance: 82,
      status: "Active",
    },
  ];

  const [students, setStudents] = useState(initialStudents);
  const [studentSearch, setStudentSearch] = useState("");
  const [studentYear, setStudentYear] = useState("All");
  const [studentSection, setStudentSection] = useState("All");
  const [showStudentForm, setShowStudentForm] = useState(false);

  const [newStudent, setNewStudent] = useState({
    id: "",
    name: "",
    email: "",
    year: "",
    section: "",
    phone: "",
  });

  /* =====================================================
     FACULTY DATA
  ===================================================== */

  const initialFaculty = [
    {
      id: "FAC001",
      name: "Dr. Anil Kumar",
      email: "anil@example.com",
      subject: "Data Science",
      experience: "12 Years",
      phone: "9876500011",
      status: "Active",
    },
    {
      id: "FAC002",
      name: "Dr. Priya Rao",
      email: "priya.rao@example.com",
      subject: "Database Management",
      experience: "9 Years",
      phone: "9876500012",
      status: "Active",
    },
    {
      id: "FAC003",
      name: "Prof. Ravi Teja",
      email: "ravi@example.com",
      subject: "Operating Systems",
      experience: "7 Years",
      phone: "9876500013",
      status: "Active",
    },
    {
      id: "FAC004",
      name: "Prof. Sneha Reddy",
      email: "sneha.reddy@example.com",
      subject: "Web Technologies",
      experience: "5 Years",
      phone: "9876500014",
      status: "Active",
    },
  ];

  const [faculty, setFaculty] = useState(initialFaculty);
  const [facultySearch, setFacultySearch] = useState("");
  const [showFacultyForm, setShowFacultyForm] = useState(false);

  const [newFaculty, setNewFaculty] = useState({
    id: "",
    name: "",
    email: "",
    subject: "",
    experience: "",
    phone: "",
  });

  /* =====================================================
     FACULTY APPROVAL DATA
  ===================================================== */

  const [facultyRequests, setFacultyRequests] = useState([
    {
      id: "REQ001",
      name: "Dr. Kiran Kumar",
      subject: "Artificial Intelligence",
      email: "kiran@example.com",
      date: "02 Oct 2026",
    },
    {
      id: "REQ002",
      name: "Prof. Lakshmi Devi",
      subject: "Computer Networks",
      email: "lakshmi@example.com",
      date: "01 Oct 2026",
    },
    {
      id: "REQ003",
      name: "Dr. Manoj Rao",
      subject: "Machine Learning",
      email: "manoj@example.com",
      date: "30 Sep 2026",
    },
  ]);

  /* =====================================================
     OUTPASS DATA
  ===================================================== */

  const [outpasses, setOutpasses] = useState([
    {
      id: "OP001",
      student: "Rahul Kumar",
      reason: "Medical Appointment",
      date: "02 Oct 2026",
      time: "10:00 AM",
      status: "Pending",
    },
    {
      id: "OP002",
      student: "Priya Sharma",
      reason: "Family Function",
      date: "03 Oct 2026",
      time: "02:00 PM",
      status: "Pending",
    },
    {
      id: "OP003",
      student: "Arjun Reddy",
      reason: "Personal Work",
      date: "03 Oct 2026",
      time: "11:30 AM",
      status: "Pending",
    },
  ]);

  /* =====================================================
     COMPLAINT DATA
  ===================================================== */

  const [complaints, setComplaints] = useState([
    {
      id: "CMP001",
      student: "Rahul Kumar",
      subject: "Classroom Facilities",
      date: "01 Oct 2026",
      priority: "Medium",
      status: "Pending",
    },
    {
      id: "CMP002",
      student: "Sneha Rao",
      subject: "Timetable Issue",
      date: "30 Sep 2026",
      priority: "High",
      status: "Under Review",
    },
    {
      id: "CMP003",
      student: "Vikram Singh",
      subject: "Lab Equipment",
      date: "29 Sep 2026",
      priority: "Low",
      status: "Resolved",
    },
  ]);

  /* =====================================================
     ANNOUNCEMENT DATA
  ===================================================== */

  const [announcements, setAnnouncements] = useState([
    {
      id: 1,
      title: "Internal Exams Schedule Released",
      audience: "All Students",
      date: "02 Oct 2026",
      status: "Published",
    },
    {
      id: 2,
      title: "Faculty Meeting - Monday",
      audience: "Faculty",
      date: "01 Oct 2026",
      status: "Published",
    },
    {
      id: 3,
      title: "Project Review Guidelines",
      audience: "III & IV Year",
      date: "28 Sep 2026",
      status: "Published",
    },
  ]);

  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false);

  const [newAnnouncement, setNewAnnouncement] = useState({
    title: "",
    audience: "",
    message: "",
  });

  /* =====================================================
     STUDENT FUNCTIONS
  ===================================================== */

  const handleStudentChange = (e) => {
    setNewStudent({
      ...newStudent,
      [e.target.name]: e.target.value,
    });
  };

  const addStudent = (e) => {
    e.preventDefault();

    if (
      !newStudent.id ||
      !newStudent.name ||
      !newStudent.email ||
      !newStudent.year ||
      !newStudent.section
    ) {
      alert("Please fill all required student fields.");
      return;
    }

    const exists = students.some(
      (student) =>
        student.id.toLowerCase() === newStudent.id.toLowerCase()
    );

    if (exists) {
      alert("Student ID already exists.");
      return;
    }

    const studentToAdd = {
      ...newStudent,
      attendance: 100,
      status: "Active",
    };

    setStudents((prev) => [...prev, studentToAdd]);

    setNewStudent({
      id: "",
      name: "",
      email: "",
      year: "",
      section: "",
      phone: "",
    });

    setShowStudentForm(false);

    alert("Student member added successfully.");
  };

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const matchesSearch =
        student.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
        student.id.toLowerCase().includes(studentSearch.toLowerCase()) ||
        student.email.toLowerCase().includes(studentSearch.toLowerCase());

      const matchesYear =
        studentYear === "All" || student.year === studentYear;

      const matchesSection =
        studentSection === "All" ||
        student.section === studentSection;

      return matchesSearch && matchesYear && matchesSection;
    });
  }, [students, studentSearch, studentYear, studentSection]);

  /* =====================================================
     FACULTY FUNCTIONS
  ===================================================== */

  const handleFacultyChange = (e) => {
    setNewFaculty({
      ...newFaculty,
      [e.target.name]: e.target.value,
    });
  };

  const addFaculty = (e) => {
    e.preventDefault();

    if (
      !newFaculty.id ||
      !newFaculty.name ||
      !newFaculty.email ||
      !newFaculty.subject ||
      !newFaculty.experience
    ) {
      alert("Please fill all required faculty fields.");
      return;
    }

    const exists = faculty.some(
      (member) =>
        member.id.toLowerCase() === newFaculty.id.toLowerCase()
    );

    if (exists) {
      alert("Faculty ID already exists.");
      return;
    }

    const facultyToAdd = {
      ...newFaculty,
      status: "Active",
    };

    setFaculty((prev) => [...prev, facultyToAdd]);

    setNewFaculty({
      id: "",
      name: "",
      email: "",
      subject: "",
      experience: "",
      phone: "",
    });

    setShowFacultyForm(false);

    alert("Faculty member added successfully.");
  };

  const filteredFaculty = useMemo(() => {
    return faculty.filter((member) =>
      `${member.id} ${member.name} ${member.email} ${member.subject}`
        .toLowerCase()
        .includes(facultySearch.toLowerCase())
    );
  }, [faculty, facultySearch]);

  /* =====================================================
     APPROVAL FUNCTIONS
  ===================================================== */

  const approveFaculty = (id) => {
    setFacultyRequests((prev) =>
      prev.filter((request) => request.id !== id)
    );

    alert("Faculty registration approved.");
  };

  const rejectFaculty = (id) => {
    setFacultyRequests((prev) =>
      prev.filter((request) => request.id !== id)
    );

    alert("Faculty registration rejected.");
  };

  /* =====================================================
     OUTPASS FUNCTIONS
  ===================================================== */

  const updateOutpass = (id, status) => {
    setOutpasses((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, status }
          : item
      )
    );

    alert(`Outpass ${status.toLowerCase()}.`);
  };

  /* =====================================================
     COMPLAINT FUNCTIONS
  ===================================================== */

  const updateComplaintStatus = (id, status) => {
    setComplaints((prev) =>
      prev.map((complaint) =>
        complaint.id === id
          ? { ...complaint, status }
          : complaint
      )
    );
  };

  /* =====================================================
     ANNOUNCEMENT FUNCTIONS
  ===================================================== */

  const handleAnnouncementChange = (e) => {
    setNewAnnouncement({
      ...newAnnouncement,
      [e.target.name]: e.target.value,
    });
  };

  const publishAnnouncement = (e) => {
    e.preventDefault();

    if (
      !newAnnouncement.title ||
      !newAnnouncement.audience ||
      !newAnnouncement.message
    ) {
      alert("Please fill all announcement fields.");
      return;
    }

    const announcement = {
      id: Date.now(),
      title: newAnnouncement.title,
      audience: newAnnouncement.audience,
      date: "02 Oct 2026",
      status: "Published",
    };

    setAnnouncements((prev) => [announcement, ...prev]);

    setNewAnnouncement({
      title: "",
      audience: "",
      message: "",
    });

    setShowAnnouncementForm(false);

    alert("Announcement published successfully.");
  };

  /* =====================================================
     HEADER
  ===================================================== */

  const Header = () => (
    <header className="module-header">

      <button
        className="back-button"
        onClick={() => navigate("/hod-dashboard")}
        title="Back to HOD Dashboard"
      >
        ←
      </button>

      <div className="header-title-area">

        <div className="module-breadcrumb">
          EduLentra / HOD / {currentPage?.title}
        </div>

        <h1>
          {currentPage?.title}
        </h1>

      </div>

      <div className="header-right">

        <div className="academic-badge">
          2026 - 2027
        </div>

      </div>

    </header>
  );

  /* =====================================================
     STUDENT MANAGEMENT
  ===================================================== */

  const StudentManagement = () => (
    <div className="module-inner">

      <div className="module-top-section">

        <div>
          <h2>Student Management</h2>

          <p>
            Manage students enrolled in the CSE department.
          </p>
        </div>

        <button
          className="primary-btn"
          onClick={() =>
            setShowStudentForm(!showStudentForm)
          }
        >
          + Add Student Member
        </button>

      </div>

      {showStudentForm && (
        <div className="member-form">

          <div className="form-heading">

            <div>
              <h3>Add Student Member</h3>

              <p>
                Enter student details to add a new department member.
              </p>
            </div>

            <button
              className="close-form"
              onClick={() => setShowStudentForm(false)}
            >
              ✕
            </button>

          </div>

          <form onSubmit={addStudent}>

            <div className="form-grid">

              <div className="form-group">
                <label>Student ID *</label>

                <input
                  type="text"
                  name="id"
                  placeholder="Example: CSE006"
                  value={newStudent.id}
                  onChange={handleStudentChange}
                />
              </div>

              <div className="form-group">
                <label>Full Name *</label>

                <input
                  type="text"
                  name="name"
                  placeholder="Enter full name"
                  value={newStudent.name}
                  onChange={handleStudentChange}
                />
              </div>

              <div className="form-group">
                <label>Email *</label>

                <input
                  type="email"
                  name="email"
                  placeholder="student@example.com"
                  value={newStudent.email}
                  onChange={handleStudentChange}
                />
              </div>

              <div className="form-group">
                <label>Year *</label>

                <select
                  name="year"
                  value={newStudent.year}
                  onChange={handleStudentChange}
                >
                  <option value="">Select Year</option>
                  <option value="I Year">I Year</option>
                  <option value="II Year">II Year</option>
                  <option value="III Year">III Year</option>
                  <option value="IV Year">IV Year</option>
                </select>
              </div>

              <div className="form-group">
                <label>Section *</label>

                <select
                  name="section"
                  value={newStudent.section}
                  onChange={handleStudentChange}
                >
                  <option value="">Select Section</option>
                  <option value="A">Section A</option>
                  <option value="B">Section B</option>
                  <option value="C">Section C</option>
                </select>
              </div>

              <div className="form-group">
                <label>Phone Number</label>

                <input
                  type="tel"
                  name="phone"
                  placeholder="Enter phone number"
                  value={newStudent.phone}
                  onChange={handleStudentChange}
                />
              </div>

            </div>

            <div className="form-actions">

              <button
                type="button"
                className="cancel-btn"
                onClick={() => setShowStudentForm(false)}
              >
                Cancel
              </button>

              <button
                type="submit"
                className="primary-btn"
              >
                + Add Student
              </button>

            </div>

          </form>

        </div>
      )}

      <div className="mini-stats">

        <div className="mini-card">
          <div className="mini-icon">👨‍🎓</div>

          <div>
            <small>Total Students</small>
            <strong>{students.length}</strong>
          </div>
        </div>

        <div className="mini-card">
          <div className="mini-icon">🟢</div>

          <div>
            <small>Active Students</small>
            <strong>
              {students.filter(
                (student) => student.status === "Active"
              ).length}
            </strong>
          </div>
        </div>

        <div className="mini-card">
          <div className="mini-icon">⚠️</div>

          <div>
            <small>Below 75%</small>
            <strong>
              {students.filter(
                (student) => student.attendance < 75
              ).length}
            </strong>
          </div>
        </div>

      </div>

      <div className="table-card">

        <div className="table-header">

          <h3>Student Members</h3>

          <div className="table-filters">

            <input
              type="text"
              placeholder="Search student..."
              value={studentSearch}
              onChange={(e) =>
                setStudentSearch(e.target.value)
              }
            />

            <select
              value={studentYear}
              onChange={(e) =>
                setStudentYear(e.target.value)
              }
            >
              <option value="All">All Years</option>
              <option value="I Year">I Year</option>
              <option value="II Year">II Year</option>
              <option value="III Year">III Year</option>
              <option value="IV Year">IV Year</option>
            </select>

            <select
              value={studentSection}
              onChange={(e) =>
                setStudentSection(e.target.value)
              }
            >
              <option value="All">All Sections</option>
              <option value="A">Section A</option>
              <option value="B">Section B</option>
              <option value="C">Section C</option>
            </select>

          </div>

        </div>

        <div className="table-wrapper">

          <table>

            <thead>
              <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Year</th>
                <th>Section</th>
                <th>Attendance</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>

              {filteredStudents.length > 0 ? (

                filteredStudents.map((student) => (

                  <tr key={student.id}>

                    <td>{student.id}</td>

                    <td className="name-cell">
                      {student.name}
                    </td>

                    <td>{student.email}</td>

                    <td>{student.year}</td>

                    <td>
                      <span className="section-badge">
                        {student.section}
                      </span>
                    </td>

                    <td>
                      <span
                        className={
                          student.attendance < 75
                            ? "attendance-low"
                            : "attendance-good"
                        }
                      >
                        {student.attendance}%
                      </span>
                    </td>

                    <td>
                      <span className="status active">
                        {student.status}
                      </span>
                    </td>

                    <td>
                      <button className="view-btn">
                        View
                      </button>
                    </td>

                  </tr>

                ))

              ) : (

                <tr>
                  <td
                    colSpan="8"
                    className="empty-table"
                  >
                    No students found.
                  </td>
                </tr>

              )}

            </tbody>

          </table>

        </div>

      </div>

    </div>
  );

  /* =====================================================
     FACULTY MANAGEMENT
  ===================================================== */

  const FacultyManagement = () => (
    <div className="module-inner">

      <div className="module-top-section">

        <div>
          <h2>Faculty Management</h2>

          <p>
            Manage faculty members of the CSE department.
          </p>
        </div>

        <button
          className="primary-btn"
          onClick={() =>
            setShowFacultyForm(!showFacultyForm)
          }
        >
          + Add Faculty Member
        </button>

      </div>

      {showFacultyForm && (
        <div className="member-form">

          <div className="form-heading">

            <div>
              <h3>Add Faculty Member</h3>

              <p>
                Enter faculty details to add a new department member.
              </p>
            </div>

            <button
              className="close-form"
              onClick={() => setShowFacultyForm(false)}
            >
              ✕
            </button>

          </div>

          <form onSubmit={addFaculty}>

            <div className="form-grid">

              <div className="form-group">
                <label>Faculty ID *</label>

                <input
                  type="text"
                  name="id"
                  placeholder="Example: FAC005"
                  value={newFaculty.id}
                  onChange={handleFacultyChange}
                />
              </div>

              <div className="form-group">
                <label>Full Name *</label>

                <input
                  type="text"
                  name="name"
                  placeholder="Enter faculty name"
                  value={newFaculty.name}
                  onChange={handleFacultyChange}
                />
              </div>

              <div className="form-group">
                <label>Email *</label>

                <input
                  type="email"
                  name="email"
                  placeholder="faculty@example.com"
                  value={newFaculty.email}
                  onChange={handleFacultyChange}
                />
              </div>

              <div className="form-group">
                <label>Subject *</label>

                <input
                  type="text"
                  name="subject"
                  placeholder="Example: Machine Learning"
                  value={newFaculty.subject}
                  onChange={handleFacultyChange}
                />
              </div>

              <div className="form-group">
                <label>Experience *</label>

                <input
                  type="text"
                  name="experience"
                  placeholder="Example: 8 Years"
                  value={newFaculty.experience}
                  onChange={handleFacultyChange}
                />
              </div>

              <div className="form-group">
                <label>Phone Number</label>

                <input
                  type="tel"
                  name="phone"
                  placeholder="Enter phone number"
                  value={newFaculty.phone}
                  onChange={handleFacultyChange}
                />
              </div>

            </div>

            <div className="form-actions">

              <button
                type="button"
                className="cancel-btn"
                onClick={() => setShowFacultyForm(false)}
              >
                Cancel
              </button>

              <button
                type="submit"
                className="primary-btn"
              >
                + Add Faculty
              </button>

            </div>

          </form>

        </div>
      )}

      <div className="mini-stats">

        <div className="mini-card">
          <div className="mini-icon">👨‍🏫</div>

          <div>
            <small>Total Faculty</small>
            <strong>{faculty.length}</strong>
          </div>
        </div>

        <div className="mini-card">
          <div className="mini-icon">🟢</div>

          <div>
            <small>Active Faculty</small>
            <strong>
              {faculty.filter(
                (member) => member.status === "Active"
              ).length}
            </strong>
          </div>
        </div>

        <div className="mini-card">
          <div className="mini-icon">📚</div>

          <div>
            <small>Subjects</small>
            <strong>
              {new Set(
                faculty.map((member) => member.subject)
              ).size}
            </strong>
          </div>
        </div>

      </div>

      <div className="table-card">

        <div className="table-header">

          <h3>Faculty Members</h3>

          <input
            type="text"
            placeholder="Search faculty..."
            value={facultySearch}
            onChange={(e) =>
              setFacultySearch(e.target.value)
            }
          />

        </div>

        <div className="table-wrapper">

          <table>

            <thead>
              <tr>
                <th>Faculty ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Experience</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>

              {filteredFaculty.length > 0 ? (

                filteredFaculty.map((member) => (

                  <tr key={member.id}>

                    <td>{member.id}</td>

                    <td className="name-cell">
                      {member.name}
                    </td>

                    <td>{member.email}</td>

                    <td>{member.subject}</td>

                    <td>{member.experience}</td>

                    <td>
                      <span className="status active">
                        {member.status}
                      </span>
                    </td>

                    <td>
                      <button className="view-btn">
                        View
                      </button>
                    </td>

                  </tr>

                ))

              ) : (

                <tr>
                  <td
                    colSpan="7"
                    className="empty-table"
                  >
                    No faculty members found.
                  </td>
                </tr>

              )}

            </tbody>

          </table>

        </div>

      </div>

    </div>
  );

  /* =====================================================
     FACULTY APPROVAL
  ===================================================== */

  const FacultyApproval = () => (
    <div className="module-inner">

      <div className="module-top-section">

        <div>
          <h2>Faculty Registration Approval</h2>

          <p>
            Review pending faculty registration requests.
          </p>
        </div>

        <div className="pending-number">
          {facultyRequests.length} Pending
        </div>

      </div>

      {facultyRequests.length > 0 ? (

        <div className="approval-list">

          {facultyRequests.map((request) => (

            <div
              className="approval-card"
              key={request.id}
            >

              <div className="approval-avatar">
                👨‍🏫
              </div>

              <div className="approval-info">

                <h3>{request.name}</h3>

                <p>
                  <strong>Subject:</strong>{" "}
                  {request.subject}
                </p>

                <p>
                  <strong>Email:</strong>{" "}
                  {request.email}
                </p>

                <small>
                  Submitted on {request.date}
                </small>

              </div>

              <div className="approval-actions">

                <button
                  className="approve-btn"
                  onClick={() =>
                    approveFaculty(request.id)
                  }
                >
                  ✓ Approve
                </button>

                <button
                  className="reject-btn"
                  onClick={() =>
                    rejectFaculty(request.id)
                  }
                >
                  ✕ Reject
                </button>

              </div>

            </div>

          ))}

        </div>

      ) : (

        <div className="empty-state">
          <div>✅</div>
          <h3>No Pending Requests</h3>
          <p>
            All faculty registration requests have been reviewed.
          </p>
        </div>

      )}

    </div>
  );

  /* =====================================================
     ATTENDANCE MONITORING
  ===================================================== */

  const AttendanceMonitoring = () => {

    const attendanceData = [
      { year: "I Year", percentage: 89 },
      { year: "II Year", percentage: 86 },
      { year: "III Year", percentage: 88 },
      { year: "IV Year", percentage: 91 },
    ];

    return (
      <div className="module-inner">

        <div className="module-top-section">

          <div>
            <h2>Attendance Monitoring</h2>

            <p>
              Monitor department-wide student attendance.
            </p>
          </div>

          <button
            className="primary-btn"
            onClick={() =>
              alert("Attendance report generated.")
            }
          >
            ↓ Export Report
          </button>

        </div>

        <div className="attendance-overview">

          <div className="attendance-big-card">
            <span>Average Attendance</span>
            <strong>87.4%</strong>
            <small>Current Academic Year</small>
          </div>

          <div className="attendance-big-card">
            <span>Above 75%</span>
            <strong>642</strong>
            <small>Students</small>
          </div>

          <div className="attendance-big-card warning-card">
            <span>Below 75%</span>
            <strong>42</strong>
            <small>Students need attention</small>
          </div>

        </div>

        <div className="attendance-chart-card">

          <div className="section-heading">
            <div>
              <h3>Year-wise Attendance</h3>
              <p>
                Average attendance by academic year
              </p>
            </div>
          </div>

          <div className="attendance-bars">

            {attendanceData.map((item) => (

              <div
                className="bar-item"
                key={item.year}
              >

                <span>{item.year}</span>

                <div className="bar-bg">
                  <div
                    style={{
                      width: `${item.percentage}%`,
                    }}
                  ></div>
                </div>

                <b>{item.percentage}%</b>

              </div>

            ))}

          </div>

        </div>

        <div className="attendance-table-card">

          <h3>Attendance Status</h3>

          <div className="attendance-status-grid">

            <div>
              <span className="dot green"></span>
              Good Attendance
              <strong>642</strong>
            </div>

            <div>
              <span className="dot yellow"></span>
              Warning
              <strong>25</strong>
            </div>

            <div>
              <span className="dot red"></span>
              Critical
              <strong>17</strong>
            </div>

          </div>

        </div>

      </div>
    );
  };

  /* =====================================================
     OUTPASS APPROVAL
  ===================================================== */

  const OutpassApproval = () => {

    const pendingOutpasses = outpasses.filter(
      (item) => item.status === "Pending"
    );

    return (
      <div className="module-inner">

        <div className="module-top-section">

          <div>
            <h2>Outpass Approval</h2>

            <p>
              Review and manage student outpass requests.
            </p>
          </div>

          <div className="pending-number">
            {pendingOutpasses.length} Pending
          </div>

        </div>

        <div className="request-grid">

          {outpasses.map((pass) => (

            <div
              className="request-card"
              key={pass.id}
            >

              <div className="request-card-top">

                <div className="request-icon">
                  🎫
                </div>

                <span
                  className={
                    pass.status === "Pending"
                      ? "status pending"
                      : pass.status === "Approved"
                      ? "status active"
                      : "status rejected"
                  }
                >
                  {pass.status}
                </span>

              </div>

              <h3>{pass.student}</h3>

              <p>
                <strong>Request ID:</strong>{" "}
                {pass.id}
              </p>

              <p>
                <strong>Reason:</strong>{" "}
                {pass.reason}
              </p>

              <p>
                <strong>Date:</strong>{" "}
                {pass.date}
              </p>

              <p>
                <strong>Time:</strong>{" "}
                {pass.time}
              </p>

              {pass.status === "Pending" && (

                <div className="request-buttons">

                  <button
                    className="approve-btn"
                    onClick={() =>
                      updateOutpass(
                        pass.id,
                        "Approved"
                      )
                    }
                  >
                    ✓ Approve
                  </button>

                  <button
                    className="reject-btn"
                    onClick={() =>
                      updateOutpass(
                        pass.id,
                        "Rejected"
                      )
                    }
                  >
                    ✕ Reject
                  </button>

                </div>

              )}

            </div>

          ))}

        </div>

      </div>
    );
  };

  /* =====================================================
     COMPLAINT MANAGEMENT
  ===================================================== */

  const ComplaintManagement = () => (

    <div className="module-inner">

      <div className="module-top-section">

        <div>
          <h2>Complaint Management</h2>

          <p>
            Review and manage student complaints.
          </p>
        </div>

        <div className="pending-number">
          {
            complaints.filter(
              (item) => item.status !== "Resolved"
            ).length
          } Pending
        </div>

      </div>

      <div className="table-card">

        <div className="table-header">

          <h3>Student Complaints</h3>

          <select
            onChange={(e) => {
              const value = e.target.value;

              if (value === "All") return;

              setComplaints((prev) => [...prev]);
            }}
          >
            <option>All Complaints</option>
            <option>Pending</option>
            <option>Under Review</option>
            <option>Resolved</option>
          </select>

        </div>

        <div className="table-wrapper">

          <table>

            <thead>

              <tr>
                <th>Complaint ID</th>
                <th>Student</th>
                <th>Subject</th>
                <th>Date</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Update</th>
              </tr>

            </thead>

            <tbody>

              {complaints.map((complaint) => (

                <tr key={complaint.id}>

                  <td>{complaint.id}</td>

                  <td className="name-cell">
                    {complaint.student}
                  </td>

                  <td>{complaint.subject}</td>

                  <td>{complaint.date}</td>

                  <td>

                    <span
                      className={`priority ${complaint.priority.toLowerCase()}`}
                    >
                      {complaint.priority}
                    </span>

                  </td>

                  <td>

                    <span
                      className={
                        complaint.status === "Resolved"
                          ? "status active"
                          : complaint.status === "Pending"
                          ? "status pending"
                          : "status review"
                      }
                    >
                      {complaint.status}
                    </span>

                  </td>

                  <td>

                    <select
                      className="status-select"
                      value={complaint.status}
                      onChange={(e) =>
                        updateComplaintStatus(
                          complaint.id,
                          e.target.value
                        )
                      }
                    >

                      <option value="Pending">
                        Pending
                      </option>

                      <option value="Under Review">
                        Under Review
                      </option>

                      <option value="Resolved">
                        Resolved
                      </option>

                    </select>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        </div>

      </div>

    </div>
  );

  /* =====================================================
     ANNOUNCEMENTS
  ===================================================== */

  const Announcements = () => (

    <div className="module-inner">

      <div className="module-top-section">

        <div>
          <h2>Department Announcements</h2>

          <p>
            Share important information with students and faculty.
          </p>
        </div>

        <button
          className="primary-btn"
          onClick={() =>
            setShowAnnouncementForm(
              !showAnnouncementForm
            )
          }
        >
          + New Announcement
        </button>

      </div>

      {showAnnouncementForm && (

        <div className="announcement-form">

          <div className="form-heading">

            <div>
              <h3>Create Announcement</h3>

              <p>
                Publish an announcement for your department.
              </p>
            </div>

            <button
              className="close-form"
              onClick={() =>
                setShowAnnouncementForm(false)
              }
            >
              ✕
            </button>

          </div>

          <form onSubmit={publishAnnouncement}>

            <div className="form-grid">

              <div className="form-group">
                <label>Announcement Title *</label>

                <input
                  type="text"
                  name="title"
                  placeholder="Enter announcement title"
                  value={newAnnouncement.title}
                  onChange={handleAnnouncementChange}
                />
              </div>

              <div className="form-group">
                <label>Audience *</label>

                <select
                  name="audience"
                  value={newAnnouncement.audience}
                  onChange={handleAnnouncementChange}
                >
                  <option value="">
                    Select Audience
                  </option>

                  <option value="All Students">
                    All Students
                  </option>

                  <option value="Faculty">
                    Faculty
                  </option>

                  <option value="III & IV Year">
                    III & IV Year
                  </option>

                  <option value="All Department">
                    All Department
                  </option>
                </select>
              </div>

              <div className="form-group full-width">

                <label>
                  Announcement Message *
                </label>

                <textarea
                  name="message"
                  rows="5"
                  placeholder="Write your announcement..."
                  value={newAnnouncement.message}
                  onChange={handleAnnouncementChange}
                ></textarea>

              </div>

            </div>

            <div className="form-actions">

              <button
                type="button"
                className="cancel-btn"
                onClick={() =>
                  setShowAnnouncementForm(false)
                }
              >
                Cancel
              </button>

              <button
                type="submit"
                className="primary-btn"
              >
                📢 Publish Announcement
              </button>

            </div>

          </form>

        </div>

      )}

      <div className="announcement-list">

        {announcements.map((announcement) => (

          <div
            className="announcement-card"
            key={announcement.id}
          >

            <div className="announcement-icon">
              📢
            </div>

            <div className="announcement-info">

              <h3>
                {announcement.title}
              </h3>

              <p>
                Audience: {announcement.audience}
              </p>

              <small>
                Published on {announcement.date}
              </small>

            </div>

            <span className="status active">
              {announcement.status}
            </span>

          </div>

        ))}

      </div>

    </div>
  );

  /* =====================================================
     DEPARTMENT REPORTS
  ===================================================== */

  const DepartmentReports = () => {

    const reports = [
      {
        icon: "📊",
        title: "Attendance Report",
        description:
          "View student attendance statistics and low-attendance records.",
      },
      {
        icon: "🎓",
        title: "Student Report",
        description:
          "Generate department student information and statistics.",
      },
      {
        icon: "👨‍🏫",
        title: "Faculty Report",
        description:
          "View faculty information, subjects and department workload.",
      },
      {
        icon: "📈",
        title: "Department Performance",
        description:
          "View overall academic and department performance.",
      },
    ];

    return (
      <div className="module-inner">

        <div className="module-top-section">

          <div>
            <h2>Department Reports</h2>

            <p>
              Generate and view department performance reports.
            </p>
          </div>

        </div>

        <div className="report-grid">

          {reports.map((report) => (

            <div
              className="report-card"
              key={report.title}
            >

              <div className="report-icon">
                {report.icon}
              </div>

              <h3>{report.title}</h3>

              <p>
                {report.description}
              </p>

              <button
                onClick={() =>
                  alert(
                    `${report.title} generated successfully.`
                  )
                }
              >
                ↓ Generate Report
              </button>

            </div>

          ))}

        </div>

      </div>
    );
  };

  /* =====================================================
     HOD PROFILE
  ===================================================== */

  const HODProfile = () => (

    <div className="module-inner">

      <div className="module-top-section">

        <div>
          <h2>HOD Profile</h2>

          <p>
            View and manage your department profile.
          </p>
        </div>

        <button
          className="primary-btn"
          onClick={() =>
            alert("Profile editing will be connected to backend later.")
          }
        >
          ✎ Edit Profile
        </button>

      </div>

      <div className="profile-card">

        <div className="profile-avatar">
          👤
        </div>

        <div className="profile-main">

          <h2>
            Dr. Rajesh Kumar
          </h2>

          <p>
            Head of Department — Computer Science & Engineering
          </p>

          <span className="status active">
            Active
          </span>

        </div>

      </div>

      <div className="profile-details">

        <div className="detail-box">
          <small>HOD ID</small>
          <strong>HOD-CSE-001</strong>
        </div>

        <div className="detail-box">
          <small>Email</small>
          <strong>hod.cse@edulentra.edu</strong>
        </div>

        <div className="detail-box">
          <small>Department</small>
          <strong>
            Computer Science & Engineering
          </strong>
        </div>

        <div className="detail-box">
          <small>Experience</small>
          <strong>15 Years</strong>
        </div>

        <div className="detail-box">
          <small>Academic Year</small>
          <strong>2026 - 2027</strong>
        </div>

        <div className="detail-box">
          <small>Office</small>
          <strong>Block A — Room 204</strong>
        </div>

      </div>

    </div>
  );

  /* =====================================================
     RENDER MODULE
  ===================================================== */

  const renderModule = () => {

    switch (location.pathname) {

      case "/student-management":
        return <StudentManagement />;

      case "/faculty-management":
        return <FacultyManagement />;

      case "/faculty-registration-approval":
        return <FacultyApproval />;

      case "/attendance-monitoring":
        return <AttendanceMonitoring />;

      case "/outpass-approval":
        return <OutpassApproval />;

      case "/complaint-management":
        return <ComplaintManagement />;

      case "/department-announcements":
        return <Announcements />;

      case "/department-reports":
        return <DepartmentReports />;

      case "/hod-profile":
        return <HODProfile />;

      default:
        return (
          <div className="empty-state">
            <div>⚠️</div>
            <h3>Module Not Found</h3>
            <button
              className="primary-btn"
              onClick={() =>
                navigate("/hod-dashboard")
              }
            >
              Back to Dashboard
            </button>
          </div>
        );
    }
  };

  /* =====================================================
     MAIN RETURN
  ===================================================== */

  return (
    <div className="hod-module-page">

      <Header />

      <main className="module-content">

        <div className="module-hero">

          <div className="module-icon">
            {currentPage?.icon}
          </div>

          <h1>
            {currentPage?.title}
          </h1>

          <p className="module-description">
            {currentPage?.description}
          </p>

        </div>

        {renderModule()}

      </main>

    </div>
  );
}

export default HODModulePage;